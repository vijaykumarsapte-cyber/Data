# Azureobservability Project

This project provisions a secure Azure Kubernetes Service (AKS) environment with networking, Azure Container Registry (ACR), and Key Vault using Terraform.

It is designed for a private, VNet-integrated setup where the AKS cluster and supporting Azure services are deployed in a secure network boundary. The DNS and database modules are currently not active in this root configuration, so the current environment focuses on AKS, ACR, networking, and Key Vault rather than PostgreSQL deployment.

## Architecture overview

The platform includes:

- Azure Resource Group
- Virtual Network with dedicated subnets for AKS and future ingress/domain use
- AKS cluster with managed identity and kubelet identity
- Azure Container Registry for application image storage
- Azure Key Vault for secrets and configuration
- A reserved application gateway subnet kept ready for future domain and ingress integration (not currently provisioned as an app gateway resource)

```mermaid
flowchart LR
    User[Developer / Operator] --> Azure[Azure Subscription]
    Azure --> RG[Resource Group]
    RG --> VNET[Virtual Network]
    VNET --> AKSSubnet[AKS Subnet]
    VNET --> AppGWSubnet[Reserved App Gateway Subnet for future ingress/domain setup]

    AKSSubnet --> AKS[AKS Cluster]
    AKS --> ACR[Azure Container Registry]
    AKS --> K8sPods[Application Pods]

    RG --> KV[Key Vault]
    AKS --> KV
    AppGWSubnet -. future ingress/domain layer .-> AKS
```

## Current Terraform configuration

This repository is configured to deploy the following environment based on the values in `terraform.tfvars`:


## Azure DevOps CI/CD pipeline

The repository includes `azure-pipelines.yml` for the Azureobservability 3-tier application.

### Pipeline stages
1. **Validate** — installs Terraform, checks formatting, initializes without a backend, validates Terraform, and checks Kubernetes YAML syntax.
2. **BuildAndPush** — builds the frontend (Node.js), backend (Go), and PostgreSQL images and pushes versioned plus `latest` tags to Azure Container Registry.
3. **Deploy** — retrieves AKS credentials, applies Kubernetes manifests, updates image tags, and waits for rollouts.

### Before the first run
- Confirm the Azure resources exist. The configured defaults are resource group `azureobservability-rg-dev`, AKS `azureobservability-aks`, and ACR `azureobservabilityacrwestusnodjs`.
- In Azure DevOps, create an Azure Resource Manager service connection named `sc-azure-observability`, or change `azureServiceConnection` in the YAML to your existing service connection.
- Grant the service connection appropriate permissions to access AKS and push images to ACR. Ensure the AKS kubelet identity has `AcrPull`.
- Add pipeline variables `AZURE_TENANT_ID` and `KEYVAULT_IDENTITY_CLIENT_ID` for the tenant ID and the user-assigned managed identity client ID used by the Key Vault CSI driver. Ensure that identity has permission to read the `DB-PASSWORD` secret in `kvazureobservabilitydev`.
- Ensure the AKS cluster has the Azure Key Vault Secrets Store CSI driver and Azure provider installed, and that the secret `DB-PASSWORD` exists in the Key Vault.
- The pipeline deploy stage runs for non-PR builds only. Review all changes before enabling automatic production deployment.

### Run it
1. Push `azure-pipelines.yml` to your Azure DevOps repository.
2. Select **Pipelines → New pipeline → Azure Repos Git → Existing Azure Pipelines YAML file**.
3. Choose `/azure-pipelines.yml`, save, and run.
4. If your branch or resource names differ, update the variables at the top of the YAML before running.

> **Important:** Renaming Terraform resource names in configuration does not rename existing Azure resources in place. Review `terraform plan` carefully before applying the renamed infrastructure. This pipeline intentionally does not run `terraform apply` automatically.
