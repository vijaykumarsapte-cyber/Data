podman build -t azureobservability-frontend:latest .

podman tag azureobservability-frontend:latest azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-frontend:latest
# ACR login
az acr login --name azureobservabilityacrwestusnodjs
# than
podman login azureobservabilityacrwestusnodjs.azurecr.io
podman push --retry=5 --retry-delay=5s azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-frontend:latest