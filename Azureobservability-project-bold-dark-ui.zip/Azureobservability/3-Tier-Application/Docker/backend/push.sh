podman build -t azureobservability-backend:latest .

podman tag azureobservability-backend:latest azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-backend:latest
# ACR login
az acr login --name azureobservabilityacrwestusnodjs
# than
podman login azureobservabilityacrwestusnodjs.azurecr.io
podman push --retry=5 --retry-delay=5s azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-backend:latest