podman build -t postgres:15 .

podman tag postgres:15 azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-postgres:latest
# ACR login
az acr login --name azureobservabilityacrwestusnodjs
# than
podman login azureobservabilityacrwestusnodjs.azurecr.io
podman push --retry=5 --retry-delay=5s azureobservabilityacrwestusnodjs.azurecr.io/azureobservability-postgres:latest